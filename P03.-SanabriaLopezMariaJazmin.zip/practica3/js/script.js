function calcular(){
   //alert("Bienvenido Maria");
   var num1 = document.getElementById("numero1").value;
   var num2 = document.getElementById("numero2").value;
   var r1 = parseInt(num1) + parseInt(num2);
   var r2 = num1 - num2;
   var r3 = num1 * num2;
   var r4 = num1/num2;
   console.log(r1);
   console.log(r2)
   console.log(r3);
   console.log(r4)
   alert("Suma: " + r1 +
       "\nResta: " + r2 +
       "\nMultiplicacion: " + r3 +
       "\nDivision: " + r4);
}