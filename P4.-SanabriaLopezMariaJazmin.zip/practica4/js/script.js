(function(){
    //alert("Bienvenido Maria");
    console.log("Maria");
    console.log(2*2);
    var num1 = document.getElementById("numero1");
    var numx = document.getElementById("numerox");
    console.log(num1);
    console.log(numx)
})();